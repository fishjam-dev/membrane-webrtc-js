import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/main.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cbf6ad4a"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cbf6ad4a"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useSyncExternalStore = __vite__cjsImport3_react["useSyncExternalStore"];
import __vite__cjsImport4_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=cbf6ad4a"; const ReactDOM = __vite__cjsImport4_reactDom_client.__esModule ? __vite__cjsImport4_reactDom_client.default : __vite__cjsImport4_reactDom_client;
import __vite__cjsImport5__jellyfishDev_membraneWebrtcJs from "/node_modules/.vite/deps/@jellyfish-dev_membrane-webrtc-js.js?v=cbf6ad4a"; const WebRTCEndpoint = __vite__cjsImport5__jellyfishDev_membraneWebrtcJs["WebRTCEndpoint"];
import { PeerMessage } from "/src/peer_notifications.ts";
const webrtc = new WebRTCEndpoint();
window.webrtc = webrtc;
function connect(token) {
  const websocketUrl = "ws://localhost:5002/socket/peer/websocket";
  const websocket = new WebSocket(websocketUrl);
  websocket.binaryType = "arraybuffer";
  function socketOpenHandler(_event) {
    const message = PeerMessage.encode({ authRequest: { token } }).finish();
    console.log(message);
    websocket.send(message);
  }
  ;
  websocket.addEventListener("open", socketOpenHandler);
  webrtc.on("sendMediaEvent", (mediaEvent) => {
    const message = PeerMessage.encode({ mediaEvent: { data: mediaEvent } }).finish();
    websocket.send(message);
  });
  webrtc.on("trackReady", (ctx) => {
    console.log(ctx);
  });
  const messageHandler = (event) => {
    const uint8Array = new Uint8Array(event.data);
    try {
      const data = PeerMessage.decode(uint8Array);
      if (data.authenticated !== void 0) {
        webrtc.connect({});
      } else if (data.authRequest !== void 0) {
        console.warn("Received unexpected control message: authRequest");
      } else if (data.mediaEvent !== void 0) {
        webrtc.receiveMediaEvent(data.mediaEvent.data);
      }
    } catch (e) {
      console.warn(`Received invalid control message, error: ${e}`);
    }
  };
  websocket.addEventListener("message", messageHandler);
}
async function addScreenshareTrack() {
  const stream = await window.navigator.mediaDevices.getDisplayMedia();
  const track = stream.getVideoTracks()[0];
  const trackMetadata = {};
  const simulcastConfig = { enabled: false, activeEncodings: [] };
  const maxBandwidth = 0;
  return webrtc.addTrack(track, stream, trackMetadata, simulcastConfig, maxBandwidth);
}
;
const DUMB_CACHE = {};
function App() {
  _s();
  const [tokenInput, setTokenInput] = useState("");
  const handleConnect = () => connect(tokenInput);
  const handleStartScreenshare = () => addScreenshareTrack();
  const remoteTracks = useSyncExternalStore((callback) => {
    webrtc.on("trackReady", callback);
    return () => {
      webrtc.removeAllListeners("trackReady");
    };
  }, () => {
    const newTracks = webrtc.getRemoteTracks();
    const ids = Object.keys(newTracks).sort().join(":");
    if (!(ids in DUMB_CACHE)) {
      DUMB_CACHE[ids] = newTracks;
    }
    return DUMB_CACHE[ids];
  });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("input", { value: tokenInput, onChange: (e) => setTokenInput(e.target.value), placeholder: "token" }, void 0, false, {
        fileName: "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx",
        lineNumber: 86,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleConnect, children: "Connect" }, void 0, false, {
        fileName: "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleStartScreenshare, children: "Start screenshare" }, void 0, false, {
        fileName: "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx",
        lineNumber: 88,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx",
      lineNumber: 85,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: Object.values(remoteTracks).map(({ stream }) => /* @__PURE__ */ jsxDEV("video", { ref: (video) => {
      video.srcObject = stream;
    }, autoPlay: true, muted: true }, stream?.id, false, {
      fileName: "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx",
      lineNumber: 91,
      columnNumber: 58
    }, this)) }, void 0, false, {
      fileName: "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx",
      lineNumber: 90,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx",
    lineNumber: 84,
    columnNumber: 5
  }, this);
}
_s(App, "m2daTBtH0KmVRCwyZ9jwZKAcjlU=", false, function() {
  return [useSyncExternalStore];
});
_c = App;
ReactDOM.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx",
    lineNumber: 99,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx",
    lineNumber: 98,
    columnNumber: 3
  }, this)
);
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kbochnia/membrane-webrtc-js/example/src/main.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUZJLG1CQUVJLGNBRko7MkJBbkZKO0FBQWdCQSxNQUFVQyxxQkFBb0Isc0JBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDN0QsT0FBT0MsY0FBYztBQUNyQixTQUFvQ0Msc0JBQW9DO0FBQ3hFLFNBQVNDLG1CQUFtQjtBQUU1QixNQUFNQyxTQUFTLElBQUlGLGVBQWU7QUFDakNHLE9BQXFERCxTQUFTQTtBQUUvRCxTQUFTRSxRQUFRQyxPQUFlO0FBQzlCLFFBQU1DLGVBQWU7QUFDckIsUUFBTUMsWUFBWSxJQUFJQyxVQUFVRixZQUFZO0FBQzVDQyxZQUFVRSxhQUFhO0FBRXZCLFdBQVNDLGtCQUFrQkMsUUFBZTtBQUN4QyxVQUFNQyxVQUFVWCxZQUFZWSxPQUFPLEVBQUVDLGFBQWEsRUFBRVQsTUFBTSxFQUFFLENBQUMsRUFBRVUsT0FBTztBQUN0RUMsWUFBUUMsSUFBSUwsT0FBTztBQUNuQkwsY0FBVVcsS0FBS04sT0FBTztBQUFBLEVBQ3hCO0FBQUM7QUFFREwsWUFBVVksaUJBQWlCLFFBQVFULGlCQUFpQjtBQUVwRFIsU0FBT2tCLEdBQUcsa0JBQWtCLENBQUNDLGVBQXFDO0FBQ2hFLFVBQU1ULFVBQVVYLFlBQVlZLE9BQU8sRUFBRVEsWUFBWSxFQUFFQyxNQUFNRCxXQUFXLEVBQUUsQ0FBQyxFQUFFTixPQUFPO0FBQ2hGUixjQUFVVyxLQUFLTixPQUFPO0FBQUEsRUFDeEIsQ0FBQztBQUVEVixTQUFPa0IsR0FBRyxjQUFjLENBQUFHLFFBQU87QUFDN0JQLFlBQVFDLElBQUlNLEdBQUc7QUFBQSxFQUNqQixDQUFDO0FBRUQsUUFBTUMsaUJBQWlCQSxDQUFDQyxVQUE2QjtBQUNuRCxVQUFNQyxhQUFhLElBQUlDLFdBQVdGLE1BQU1ILElBQUk7QUFDNUMsUUFBSTtBQUNGLFlBQU1BLE9BQU9yQixZQUFZMkIsT0FBT0YsVUFBVTtBQUMxQyxVQUFJSixLQUFLTyxrQkFBa0JDLFFBQVc7QUFDcEM1QixlQUFPRSxRQUFRLENBQUMsQ0FBQztBQUFBLE1BQ25CLFdBQVdrQixLQUFLUixnQkFBZ0JnQixRQUFXO0FBQ3pDZCxnQkFBUWUsS0FBSyxrREFBa0Q7QUFBQSxNQUNqRSxXQUFXVCxLQUFLRCxlQUFlUyxRQUFXO0FBQ3hDNUIsZUFBTzhCLGtCQUFrQlYsS0FBS0QsV0FBV0MsSUFBSTtBQUFBLE1BQy9DO0FBQUEsSUFDRixTQUFTVyxHQUFHO0FBQ1ZqQixjQUFRZSxLQUFNLDRDQUEyQ0UsQ0FBRSxFQUFDO0FBQUEsSUFDOUQ7QUFBQSxFQUNGO0FBRUExQixZQUFVWSxpQkFBaUIsV0FBV0ssY0FBYztBQUN0RDtBQUVBLGVBQWVVLHNCQUF1QztBQUNsRCxRQUFNQyxTQUFTLE1BQU1oQyxPQUFPaUMsVUFBVUMsYUFBYUMsZ0JBQWdCO0FBQ25FLFFBQU1DLFFBQVFKLE9BQU9LLGVBQWUsRUFBRSxDQUFDO0FBRXZDLFFBQU1DLGdCQUFnQixDQUFDO0FBQ3ZCLFFBQU1DLGtCQUFrQixFQUFFQyxTQUFTLE9BQU9DLGlCQUFpQixHQUFHO0FBQzlELFFBQU1DLGVBQWU7QUFFckIsU0FBTzNDLE9BQU80QyxTQUFTUCxPQUFPSixRQUFRTSxlQUFlQyxpQkFBaUJHLFlBQVk7QUFDdEY7QUFBQztBQUVELE1BQU1FLGFBQTJELENBQUM7QUFFbEUsU0FBU0MsTUFBTTtBQUFBQyxLQUFBO0FBQ2IsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUl0RCxTQUFTLEVBQUU7QUFFL0MsUUFBTXVELGdCQUFnQkEsTUFBTWhELFFBQVE4QyxVQUFVO0FBQzlDLFFBQU1HLHlCQUF5QkEsTUFBTW5CLG9CQUFvQjtBQUV6RCxRQUFNb0IsZUFBZXhELHFCQUFxQixDQUFDeUQsYUFBYTtBQUN0RHJELFdBQU9rQixHQUFHLGNBQWNtQyxRQUFRO0FBQ2hDLFdBQU8sTUFBTTtBQUNYckQsYUFBT3NELG1CQUFtQixZQUFZO0FBQUEsSUFDeEM7QUFBQSxFQUNGLEdBQUcsTUFBTTtBQUNQLFVBQU1DLFlBQVl2RCxPQUFPd0QsZ0JBQWdCO0FBQ3pDLFVBQU1DLE1BQU1DLE9BQU9DLEtBQUtKLFNBQVMsRUFBRUssS0FBSyxFQUFFQyxLQUFLLEdBQUc7QUFDbEQsUUFBSSxFQUFFSixPQUFPWixhQUFhO0FBQ3hCQSxpQkFBV1ksR0FBRyxJQUFJRjtBQUFBQSxJQUNwQjtBQUNBLFdBQU9WLFdBQVdZLEdBQUc7QUFBQSxFQUN2QixDQUFDO0FBRUQsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQ0M7QUFBQSw2QkFBQyxXQUFNLE9BQU9ULFlBQVksVUFBVSxDQUFDakIsTUFBTWtCLGNBQWNsQixFQUFFK0IsT0FBT0MsS0FBSyxHQUFHLGFBQVksV0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RjtBQUFBLE1BQzdGLHVCQUFDLFlBQU8sU0FBU2IsZUFBZSx1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQ3ZDLHVCQUFDLFlBQU8sU0FBU0Msd0JBQXdCLGlDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsU0FINUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFDQSx1QkFBQyxTQUNFTyxpQkFBT00sT0FBT1osWUFBWSxFQUFFYSxJQUFJLENBQUMsRUFBQ2hDLE9BQU0sTUFBTSx1QkFBQyxXQUF1QixLQUFLLENBQUFpQyxVQUFTO0FBQUNBLFlBQU9DLFlBQVlsQztBQUFBQSxJQUFNLEdBQUcsVUFBUSxNQUFDLE9BQUssUUFBckVBLFFBQVFtQyxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlGLENBQUUsS0FEcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFFSjtBQUFDckIsR0FoQ1FELEtBQUc7QUFBQSxVQU1XbEQsb0JBQW9CO0FBQUE7QUFBQXlFLEtBTmxDdkI7QUFrQ1RqRCxTQUFTeUUsV0FBV0MsU0FBU0MsZUFBZSxNQUFNLENBQUUsRUFBRUM7QUFBQUEsRUFDcEQsdUJBQUMsTUFBTSxZQUFOLEVBQ0MsaUNBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQUksS0FETjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFDRjtBQUFDLElBQUFKO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVN5bmNFeHRlcm5hbFN0b3JlIiwiUmVhY3RET00iLCJXZWJSVENFbmRwb2ludCIsIlBlZXJNZXNzYWdlIiwid2VicnRjIiwid2luZG93IiwiY29ubmVjdCIsInRva2VuIiwid2Vic29ja2V0VXJsIiwid2Vic29ja2V0IiwiV2ViU29ja2V0IiwiYmluYXJ5VHlwZSIsInNvY2tldE9wZW5IYW5kbGVyIiwiX2V2ZW50IiwibWVzc2FnZSIsImVuY29kZSIsImF1dGhSZXF1ZXN0IiwiZmluaXNoIiwiY29uc29sZSIsImxvZyIsInNlbmQiLCJhZGRFdmVudExpc3RlbmVyIiwib24iLCJtZWRpYUV2ZW50IiwiZGF0YSIsImN0eCIsIm1lc3NhZ2VIYW5kbGVyIiwiZXZlbnQiLCJ1aW50OEFycmF5IiwiVWludDhBcnJheSIsImRlY29kZSIsImF1dGhlbnRpY2F0ZWQiLCJ1bmRlZmluZWQiLCJ3YXJuIiwicmVjZWl2ZU1lZGlhRXZlbnQiLCJlIiwiYWRkU2NyZWVuc2hhcmVUcmFjayIsInN0cmVhbSIsIm5hdmlnYXRvciIsIm1lZGlhRGV2aWNlcyIsImdldERpc3BsYXlNZWRpYSIsInRyYWNrIiwiZ2V0VmlkZW9UcmFja3MiLCJ0cmFja01ldGFkYXRhIiwic2ltdWxjYXN0Q29uZmlnIiwiZW5hYmxlZCIsImFjdGl2ZUVuY29kaW5ncyIsIm1heEJhbmR3aWR0aCIsImFkZFRyYWNrIiwiRFVNQl9DQUNIRSIsIkFwcCIsIl9zIiwidG9rZW5JbnB1dCIsInNldFRva2VuSW5wdXQiLCJoYW5kbGVDb25uZWN0IiwiaGFuZGxlU3RhcnRTY3JlZW5zaGFyZSIsInJlbW90ZVRyYWNrcyIsImNhbGxiYWNrIiwicmVtb3ZlQWxsTGlzdGVuZXJzIiwibmV3VHJhY2tzIiwiZ2V0UmVtb3RlVHJhY2tzIiwiaWRzIiwiT2JqZWN0Iiwia2V5cyIsInNvcnQiLCJqb2luIiwidGFyZ2V0IiwidmFsdWUiLCJ2YWx1ZXMiLCJtYXAiLCJ2aWRlbyIsInNyY09iamVjdCIsImlkIiwiX2MiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlU3luY0V4dGVybmFsU3RvcmUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20vY2xpZW50J1xuaW1wb3J0IHsgdHlwZSBTZXJpYWxpemVkTWVkaWFFdmVudCwgV2ViUlRDRW5kcG9pbnQsIFRyYWNrQ29udGV4dCB9IGZyb20gXCJAamVsbHlmaXNoLWRldi9tZW1icmFuZS13ZWJydGMtanNcIjtcbmltcG9ydCB7IFBlZXJNZXNzYWdlIH0gZnJvbSBcIi4vcGVlcl9ub3RpZmljYXRpb25zXCJcblxuY29uc3Qgd2VicnRjID0gbmV3IFdlYlJUQ0VuZHBvaW50KCk7XG4od2luZG93IGFzIHR5cGVvZiB3aW5kb3cgJiB7IHdlYnJ0YzogV2ViUlRDRW5kcG9pbnR9KS53ZWJydGMgPSB3ZWJydGM7XG5cbmZ1bmN0aW9uIGNvbm5lY3QodG9rZW46IHN0cmluZykge1xuICBjb25zdCB3ZWJzb2NrZXRVcmwgPSBcIndzOi8vbG9jYWxob3N0OjUwMDIvc29ja2V0L3BlZXIvd2Vic29ja2V0XCI7XG4gIGNvbnN0IHdlYnNvY2tldCA9IG5ldyBXZWJTb2NrZXQod2Vic29ja2V0VXJsKTtcbiAgd2Vic29ja2V0LmJpbmFyeVR5cGUgPSBcImFycmF5YnVmZmVyXCI7XG5cbiAgZnVuY3Rpb24gc29ja2V0T3BlbkhhbmRsZXIoX2V2ZW50OiBFdmVudCkge1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBQZWVyTWVzc2FnZS5lbmNvZGUoeyBhdXRoUmVxdWVzdDogeyB0b2tlbiB9IH0pLmZpbmlzaCgpO1xuICAgIGNvbnNvbGUubG9nKG1lc3NhZ2UpXG4gICAgd2Vic29ja2V0LnNlbmQobWVzc2FnZSk7XG4gIH07XG5cbiAgd2Vic29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoXCJvcGVuXCIsIHNvY2tldE9wZW5IYW5kbGVyKTtcblxuICB3ZWJydGMub24oXCJzZW5kTWVkaWFFdmVudFwiLCAobWVkaWFFdmVudDogU2VyaWFsaXplZE1lZGlhRXZlbnQpID0+IHtcbiAgICBjb25zdCBtZXNzYWdlID0gUGVlck1lc3NhZ2UuZW5jb2RlKHsgbWVkaWFFdmVudDogeyBkYXRhOiBtZWRpYUV2ZW50IH0gfSkuZmluaXNoKCk7XG4gICAgd2Vic29ja2V0LnNlbmQobWVzc2FnZSk7XG4gIH0pO1xuICBcbiAgd2VicnRjLm9uKFwidHJhY2tSZWFkeVwiLCBjdHggPT4ge1xuICAgIGNvbnNvbGUubG9nKGN0eCk7XG4gIH0pXG5cbiAgY29uc3QgbWVzc2FnZUhhbmRsZXIgPSAoZXZlbnQ6IE1lc3NhZ2VFdmVudDxhbnk+KSA9PiB7XG4gICAgY29uc3QgdWludDhBcnJheSA9IG5ldyBVaW50OEFycmF5KGV2ZW50LmRhdGEpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gUGVlck1lc3NhZ2UuZGVjb2RlKHVpbnQ4QXJyYXkpO1xuICAgICAgaWYgKGRhdGEuYXV0aGVudGljYXRlZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHdlYnJ0Yy5jb25uZWN0KHt9KTtcbiAgICAgIH0gZWxzZSBpZiAoZGF0YS5hdXRoUmVxdWVzdCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcIlJlY2VpdmVkIHVuZXhwZWN0ZWQgY29udHJvbCBtZXNzYWdlOiBhdXRoUmVxdWVzdFwiKTtcbiAgICAgIH0gZWxzZSBpZiAoZGF0YS5tZWRpYUV2ZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgd2VicnRjLnJlY2VpdmVNZWRpYUV2ZW50KGRhdGEubWVkaWFFdmVudC5kYXRhKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLndhcm4oYFJlY2VpdmVkIGludmFsaWQgY29udHJvbCBtZXNzYWdlLCBlcnJvcjogJHtlfWApO1xuICAgIH1cbiAgfTtcblxuICB3ZWJzb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgbWVzc2FnZUhhbmRsZXIpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBhZGRTY3JlZW5zaGFyZVRyYWNrKCk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgd2luZG93Lm5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0RGlzcGxheU1lZGlhKCk7XG4gICAgY29uc3QgdHJhY2sgPSBzdHJlYW0uZ2V0VmlkZW9UcmFja3MoKVswXTtcblxuICAgIGNvbnN0IHRyYWNrTWV0YWRhdGEgPSB7fTtcbiAgICBjb25zdCBzaW11bGNhc3RDb25maWcgPSB7IGVuYWJsZWQ6IGZhbHNlLCBhY3RpdmVFbmNvZGluZ3M6IFtdIH07XG4gICAgY29uc3QgbWF4QmFuZHdpZHRoID0gMDtcblxuICAgIHJldHVybiB3ZWJydGMuYWRkVHJhY2sodHJhY2ssIHN0cmVhbSwgdHJhY2tNZXRhZGF0YSwgc2ltdWxjYXN0Q29uZmlnLCBtYXhCYW5kd2lkdGgpO1xufTtcblxuY29uc3QgRFVNQl9DQUNIRTogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgVHJhY2tDb250ZXh0Pj4gPSB7fTtcblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBbdG9rZW5JbnB1dCwgc2V0VG9rZW5JbnB1dF0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCBoYW5kbGVDb25uZWN0ID0gKCkgPT4gY29ubmVjdCh0b2tlbklucHV0KTtcbiAgY29uc3QgaGFuZGxlU3RhcnRTY3JlZW5zaGFyZSA9ICgpID0+IGFkZFNjcmVlbnNoYXJlVHJhY2soKTtcblxuICBjb25zdCByZW1vdGVUcmFja3MgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZSgoY2FsbGJhY2spID0+IHtcbiAgICB3ZWJydGMub24oXCJ0cmFja1JlYWR5XCIsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgd2VicnRjLnJlbW92ZUFsbExpc3RlbmVycyhcInRyYWNrUmVhZHlcIik7XG4gICAgfVxuICB9LCAoKSA9PiB7XG4gICAgY29uc3QgbmV3VHJhY2tzID0gd2VicnRjLmdldFJlbW90ZVRyYWNrcygpO1xuICAgIGNvbnN0IGlkcyA9IE9iamVjdC5rZXlzKG5ld1RyYWNrcykuc29ydCgpLmpvaW4oXCI6XCIpO1xuICAgIGlmICghKGlkcyBpbiBEVU1CX0NBQ0hFKSkge1xuICAgICAgRFVNQl9DQUNIRVtpZHNdID0gbmV3VHJhY2tzO1xuICAgIH1cbiAgICByZXR1cm4gRFVNQl9DQUNIRVtpZHNdO1xuICB9KTtcbiAgICBcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdj5cbiAgICAgICAgPGlucHV0IHZhbHVlPXt0b2tlbklucHV0fSBvbkNoYW5nZT17KGUpID0+IHNldFRva2VuSW5wdXQoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cInRva2VuXCIgLz5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVDb25uZWN0fT5Db25uZWN0PC9idXR0b24+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlU3RhcnRTY3JlZW5zaGFyZX0+U3RhcnQgc2NyZWVuc2hhcmU8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdj5cbiAgICAgICAge09iamVjdC52YWx1ZXMocmVtb3RlVHJhY2tzKS5tYXAoKHtzdHJlYW19KSA9PiA8dmlkZW8ga2V5PXtzdHJlYW0/LmlkfSByZWY9e3ZpZGVvID0+IHt2aWRlbyEuc3JjT2JqZWN0ID0gc3RyZWFtfX0gYXV0b1BsYXkgbXV0ZWQvPil9XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKVxufVxuXG5SZWFjdERPTS5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykhKS5yZW5kZXIoXG4gIDxSZWFjdC5TdHJpY3RNb2RlPlxuICAgIDxBcHAgLz5cbiAgPC9SZWFjdC5TdHJpY3RNb2RlPixcbilcbiJdLCJmaWxlIjoiL1VzZXJzL2tib2NobmlhL21lbWJyYW5lLXdlYnJ0Yy1qcy9leGFtcGxlL3NyYy9tYWluLnRzeCJ9