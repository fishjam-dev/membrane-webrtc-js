import {
  require_react
} from "/node_modules/.vite/deps/chunk-R2PSMBUW.js?v=cbf6ad4a";
import "/node_modules/.vite/deps/chunk-CF3WPAMV.js?v=cbf6ad4a";
export default require_react();
//# sourceMappingURL=react.js.map
