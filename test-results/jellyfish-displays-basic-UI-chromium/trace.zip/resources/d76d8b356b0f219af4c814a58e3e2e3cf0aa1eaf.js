import {
  __commonJS,
  __esm,
  __export,
  __toCommonJS
} from "/node_modules/.vite/deps/chunk-CF3WPAMV.js?v=cbf6ad4a";

// ../dist/mediaEvent.js
var require_mediaEvent = __commonJS({
  "../dist/mediaEvent.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.generateCustomEvent = exports.generateMediaEvent = exports.deserializeMediaEvent = exports.serializeMediaEvent = void 0;
    function serializeMediaEvent(mediaEvent) {
      return JSON.stringify(mediaEvent);
    }
    exports.serializeMediaEvent = serializeMediaEvent;
    function deserializeMediaEvent(serializedMediaEvent) {
      return JSON.parse(serializedMediaEvent);
    }
    exports.deserializeMediaEvent = deserializeMediaEvent;
    function generateMediaEvent(type, data) {
      let event = { type };
      if (data) {
        event = { ...event, data };
      }
      return event;
    }
    exports.generateMediaEvent = generateMediaEvent;
    function generateCustomEvent(data) {
      return generateMediaEvent("custom", data);
    }
    exports.generateCustomEvent = generateCustomEvent;
  }
});

// ../node_modules/uuid/dist/esm-browser/rng.js
function rng() {
  if (!getRandomValues) {
    getRandomValues = typeof crypto !== "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto !== "undefined" && typeof msCrypto.getRandomValues === "function" && msCrypto.getRandomValues.bind(msCrypto);
    if (!getRandomValues) {
      throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    }
  }
  return getRandomValues(rnds8);
}
var getRandomValues, rnds8;
var init_rng = __esm({
  "../node_modules/uuid/dist/esm-browser/rng.js"() {
    rnds8 = new Uint8Array(16);
  }
});

// ../node_modules/uuid/dist/esm-browser/regex.js
var regex_default;
var init_regex = __esm({
  "../node_modules/uuid/dist/esm-browser/regex.js"() {
    regex_default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
  }
});

// ../node_modules/uuid/dist/esm-browser/validate.js
function validate(uuid) {
  return typeof uuid === "string" && regex_default.test(uuid);
}
var validate_default;
var init_validate = __esm({
  "../node_modules/uuid/dist/esm-browser/validate.js"() {
    init_regex();
    validate_default = validate;
  }
});

// ../node_modules/uuid/dist/esm-browser/stringify.js
function stringify(arr) {
  var offset = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
  var uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
  if (!validate_default(uuid)) {
    throw TypeError("Stringified UUID is invalid");
  }
  return uuid;
}
var byteToHex, i, stringify_default;
var init_stringify = __esm({
  "../node_modules/uuid/dist/esm-browser/stringify.js"() {
    init_validate();
    byteToHex = [];
    for (i = 0; i < 256; ++i) {
      byteToHex.push((i + 256).toString(16).substr(1));
    }
    stringify_default = stringify;
  }
});

// ../node_modules/uuid/dist/esm-browser/v1.js
function v1(options, buf, offset) {
  var i = buf && offset || 0;
  var b = buf || new Array(16);
  options = options || {};
  var node = options.node || _nodeId;
  var clockseq = options.clockseq !== void 0 ? options.clockseq : _clockseq;
  if (node == null || clockseq == null) {
    var seedBytes = options.random || (options.rng || rng)();
    if (node == null) {
      node = _nodeId = [seedBytes[0] | 1, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
    }
    if (clockseq == null) {
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 16383;
    }
  }
  var msecs = options.msecs !== void 0 ? options.msecs : Date.now();
  var nsecs = options.nsecs !== void 0 ? options.nsecs : _lastNSecs + 1;
  var dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 1e4;
  if (dt < 0 && options.clockseq === void 0) {
    clockseq = clockseq + 1 & 16383;
  }
  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === void 0) {
    nsecs = 0;
  }
  if (nsecs >= 1e4) {
    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
  }
  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq;
  msecs += 122192928e5;
  var tl = ((msecs & 268435455) * 1e4 + nsecs) % 4294967296;
  b[i++] = tl >>> 24 & 255;
  b[i++] = tl >>> 16 & 255;
  b[i++] = tl >>> 8 & 255;
  b[i++] = tl & 255;
  var tmh = msecs / 4294967296 * 1e4 & 268435455;
  b[i++] = tmh >>> 8 & 255;
  b[i++] = tmh & 255;
  b[i++] = tmh >>> 24 & 15 | 16;
  b[i++] = tmh >>> 16 & 255;
  b[i++] = clockseq >>> 8 | 128;
  b[i++] = clockseq & 255;
  for (var n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }
  return buf || stringify_default(b);
}
var _nodeId, _clockseq, _lastMSecs, _lastNSecs, v1_default;
var init_v1 = __esm({
  "../node_modules/uuid/dist/esm-browser/v1.js"() {
    init_rng();
    init_stringify();
    _lastMSecs = 0;
    _lastNSecs = 0;
    v1_default = v1;
  }
});

// ../node_modules/uuid/dist/esm-browser/parse.js
function parse(uuid) {
  if (!validate_default(uuid)) {
    throw TypeError("Invalid UUID");
  }
  var v;
  var arr = new Uint8Array(16);
  arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
  arr[1] = v >>> 16 & 255;
  arr[2] = v >>> 8 & 255;
  arr[3] = v & 255;
  arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
  arr[5] = v & 255;
  arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
  arr[7] = v & 255;
  arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
  arr[9] = v & 255;
  arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 1099511627776 & 255;
  arr[11] = v / 4294967296 & 255;
  arr[12] = v >>> 24 & 255;
  arr[13] = v >>> 16 & 255;
  arr[14] = v >>> 8 & 255;
  arr[15] = v & 255;
  return arr;
}
var parse_default;
var init_parse = __esm({
  "../node_modules/uuid/dist/esm-browser/parse.js"() {
    init_validate();
    parse_default = parse;
  }
});

// ../node_modules/uuid/dist/esm-browser/v35.js
function stringToBytes(str) {
  str = unescape(encodeURIComponent(str));
  var bytes = [];
  for (var i = 0; i < str.length; ++i) {
    bytes.push(str.charCodeAt(i));
  }
  return bytes;
}
function v35_default(name, version2, hashfunc) {
  function generateUUID(value, namespace, buf, offset) {
    if (typeof value === "string") {
      value = stringToBytes(value);
    }
    if (typeof namespace === "string") {
      namespace = parse_default(namespace);
    }
    if (namespace.length !== 16) {
      throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
    }
    var bytes = new Uint8Array(16 + value.length);
    bytes.set(namespace);
    bytes.set(value, namespace.length);
    bytes = hashfunc(bytes);
    bytes[6] = bytes[6] & 15 | version2;
    bytes[8] = bytes[8] & 63 | 128;
    if (buf) {
      offset = offset || 0;
      for (var i = 0; i < 16; ++i) {
        buf[offset + i] = bytes[i];
      }
      return buf;
    }
    return stringify_default(bytes);
  }
  try {
    generateUUID.name = name;
  } catch (err) {
  }
  generateUUID.DNS = DNS;
  generateUUID.URL = URL;
  return generateUUID;
}
var DNS, URL;
var init_v35 = __esm({
  "../node_modules/uuid/dist/esm-browser/v35.js"() {
    init_stringify();
    init_parse();
    DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
    URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
  }
});

// ../node_modules/uuid/dist/esm-browser/md5.js
function md5(bytes) {
  if (typeof bytes === "string") {
    var msg = unescape(encodeURIComponent(bytes));
    bytes = new Uint8Array(msg.length);
    for (var i = 0; i < msg.length; ++i) {
      bytes[i] = msg.charCodeAt(i);
    }
  }
  return md5ToHexEncodedArray(wordsToMd5(bytesToWords(bytes), bytes.length * 8));
}
function md5ToHexEncodedArray(input) {
  var output = [];
  var length32 = input.length * 32;
  var hexTab = "0123456789abcdef";
  for (var i = 0; i < length32; i += 8) {
    var x = input[i >> 5] >>> i % 32 & 255;
    var hex = parseInt(hexTab.charAt(x >>> 4 & 15) + hexTab.charAt(x & 15), 16);
    output.push(hex);
  }
  return output;
}
function getOutputLength(inputLength8) {
  return (inputLength8 + 64 >>> 9 << 4) + 14 + 1;
}
function wordsToMd5(x, len) {
  x[len >> 5] |= 128 << len % 32;
  x[getOutputLength(len) - 1] = len;
  var a = 1732584193;
  var b = -271733879;
  var c = -1732584194;
  var d = 271733878;
  for (var i = 0; i < x.length; i += 16) {
    var olda = a;
    var oldb = b;
    var oldc = c;
    var oldd = d;
    a = md5ff(a, b, c, d, x[i], 7, -680876936);
    d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
    b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
    d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
    b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
    d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
    b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
    d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
    b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
    d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
    b = md5gg(b, c, d, a, x[i], 20, -373897302);
    a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
    d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
    b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
    d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
    b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
    d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
    b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
    d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
    b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
    d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
    b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
    d = md5hh(d, a, b, c, x[i], 11, -358537222);
    c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
    b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
    d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
    b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = md5ii(a, b, c, d, x[i], 6, -198630844);
    d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
    b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
    d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
    b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
    d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
    b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
    d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
    b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = safeAdd(a, olda);
    b = safeAdd(b, oldb);
    c = safeAdd(c, oldc);
    d = safeAdd(d, oldd);
  }
  return [a, b, c, d];
}
function bytesToWords(input) {
  if (input.length === 0) {
    return [];
  }
  var length8 = input.length * 8;
  var output = new Uint32Array(getOutputLength(length8));
  for (var i = 0; i < length8; i += 8) {
    output[i >> 5] |= (input[i / 8] & 255) << i % 32;
  }
  return output;
}
function safeAdd(x, y) {
  var lsw = (x & 65535) + (y & 65535);
  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return msw << 16 | lsw & 65535;
}
function bitRotateLeft(num, cnt) {
  return num << cnt | num >>> 32 - cnt;
}
function md5cmn(q, a, b, x, s, t) {
  return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}
function md5ff(a, b, c, d, x, s, t) {
  return md5cmn(b & c | ~b & d, a, b, x, s, t);
}
function md5gg(a, b, c, d, x, s, t) {
  return md5cmn(b & d | c & ~d, a, b, x, s, t);
}
function md5hh(a, b, c, d, x, s, t) {
  return md5cmn(b ^ c ^ d, a, b, x, s, t);
}
function md5ii(a, b, c, d, x, s, t) {
  return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}
var md5_default;
var init_md5 = __esm({
  "../node_modules/uuid/dist/esm-browser/md5.js"() {
    md5_default = md5;
  }
});

// ../node_modules/uuid/dist/esm-browser/v3.js
var v3, v3_default;
var init_v3 = __esm({
  "../node_modules/uuid/dist/esm-browser/v3.js"() {
    init_v35();
    init_md5();
    v3 = v35_default("v3", 48, md5_default);
    v3_default = v3;
  }
});

// ../node_modules/uuid/dist/esm-browser/v4.js
function v4(options, buf, offset) {
  options = options || {};
  var rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    for (var i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return stringify_default(rnds);
}
var v4_default;
var init_v4 = __esm({
  "../node_modules/uuid/dist/esm-browser/v4.js"() {
    init_rng();
    init_stringify();
    v4_default = v4;
  }
});

// ../node_modules/uuid/dist/esm-browser/sha1.js
function f(s, x, y, z) {
  switch (s) {
    case 0:
      return x & y ^ ~x & z;
    case 1:
      return x ^ y ^ z;
    case 2:
      return x & y ^ x & z ^ y & z;
    case 3:
      return x ^ y ^ z;
  }
}
function ROTL(x, n) {
  return x << n | x >>> 32 - n;
}
function sha1(bytes) {
  var K = [1518500249, 1859775393, 2400959708, 3395469782];
  var H = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
  if (typeof bytes === "string") {
    var msg = unescape(encodeURIComponent(bytes));
    bytes = [];
    for (var i = 0; i < msg.length; ++i) {
      bytes.push(msg.charCodeAt(i));
    }
  } else if (!Array.isArray(bytes)) {
    bytes = Array.prototype.slice.call(bytes);
  }
  bytes.push(128);
  var l = bytes.length / 4 + 2;
  var N = Math.ceil(l / 16);
  var M = new Array(N);
  for (var _i = 0; _i < N; ++_i) {
    var arr = new Uint32Array(16);
    for (var j = 0; j < 16; ++j) {
      arr[j] = bytes[_i * 64 + j * 4] << 24 | bytes[_i * 64 + j * 4 + 1] << 16 | bytes[_i * 64 + j * 4 + 2] << 8 | bytes[_i * 64 + j * 4 + 3];
    }
    M[_i] = arr;
  }
  M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
  M[N - 1][14] = Math.floor(M[N - 1][14]);
  M[N - 1][15] = (bytes.length - 1) * 8 & 4294967295;
  for (var _i2 = 0; _i2 < N; ++_i2) {
    var W = new Uint32Array(80);
    for (var t = 0; t < 16; ++t) {
      W[t] = M[_i2][t];
    }
    for (var _t = 16; _t < 80; ++_t) {
      W[_t] = ROTL(W[_t - 3] ^ W[_t - 8] ^ W[_t - 14] ^ W[_t - 16], 1);
    }
    var a = H[0];
    var b = H[1];
    var c = H[2];
    var d = H[3];
    var e = H[4];
    for (var _t2 = 0; _t2 < 80; ++_t2) {
      var s = Math.floor(_t2 / 20);
      var T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[_t2] >>> 0;
      e = d;
      d = c;
      c = ROTL(b, 30) >>> 0;
      b = a;
      a = T;
    }
    H[0] = H[0] + a >>> 0;
    H[1] = H[1] + b >>> 0;
    H[2] = H[2] + c >>> 0;
    H[3] = H[3] + d >>> 0;
    H[4] = H[4] + e >>> 0;
  }
  return [H[0] >> 24 & 255, H[0] >> 16 & 255, H[0] >> 8 & 255, H[0] & 255, H[1] >> 24 & 255, H[1] >> 16 & 255, H[1] >> 8 & 255, H[1] & 255, H[2] >> 24 & 255, H[2] >> 16 & 255, H[2] >> 8 & 255, H[2] & 255, H[3] >> 24 & 255, H[3] >> 16 & 255, H[3] >> 8 & 255, H[3] & 255, H[4] >> 24 & 255, H[4] >> 16 & 255, H[4] >> 8 & 255, H[4] & 255];
}
var sha1_default;
var init_sha1 = __esm({
  "../node_modules/uuid/dist/esm-browser/sha1.js"() {
    sha1_default = sha1;
  }
});

// ../node_modules/uuid/dist/esm-browser/v5.js
var v5, v5_default;
var init_v5 = __esm({
  "../node_modules/uuid/dist/esm-browser/v5.js"() {
    init_v35();
    init_sha1();
    v5 = v35_default("v5", 80, sha1_default);
    v5_default = v5;
  }
});

// ../node_modules/uuid/dist/esm-browser/nil.js
var nil_default;
var init_nil = __esm({
  "../node_modules/uuid/dist/esm-browser/nil.js"() {
    nil_default = "00000000-0000-0000-0000-000000000000";
  }
});

// ../node_modules/uuid/dist/esm-browser/version.js
function version(uuid) {
  if (!validate_default(uuid)) {
    throw TypeError("Invalid UUID");
  }
  return parseInt(uuid.substr(14, 1), 16);
}
var version_default;
var init_version = __esm({
  "../node_modules/uuid/dist/esm-browser/version.js"() {
    init_validate();
    version_default = version;
  }
});

// ../node_modules/uuid/dist/esm-browser/index.js
var esm_browser_exports = {};
__export(esm_browser_exports, {
  NIL: () => nil_default,
  parse: () => parse_default,
  stringify: () => stringify_default,
  v1: () => v1_default,
  v3: () => v3_default,
  v4: () => v4_default,
  v5: () => v5_default,
  validate: () => validate_default,
  version: () => version_default
});
var init_esm_browser = __esm({
  "../node_modules/uuid/dist/esm-browser/index.js"() {
    init_v1();
    init_v3();
    init_v4();
    init_v5();
    init_nil();
    init_version();
    init_validate();
    init_stringify();
    init_parse();
  }
});

// ../node_modules/events/events.js
var require_events = __commonJS({
  "../node_modules/events/events.js"(exports, module) {
    "use strict";
    var R = typeof Reflect === "object" ? Reflect : null;
    var ReflectApply = R && typeof R.apply === "function" ? R.apply : function ReflectApply2(target, receiver, args) {
      return Function.prototype.apply.call(target, receiver, args);
    };
    var ReflectOwnKeys;
    if (R && typeof R.ownKeys === "function") {
      ReflectOwnKeys = R.ownKeys;
    } else if (Object.getOwnPropertySymbols) {
      ReflectOwnKeys = function ReflectOwnKeys2(target) {
        return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
      };
    } else {
      ReflectOwnKeys = function ReflectOwnKeys2(target) {
        return Object.getOwnPropertyNames(target);
      };
    }
    function ProcessEmitWarning(warning) {
      if (console && console.warn)
        console.warn(warning);
    }
    var NumberIsNaN = Number.isNaN || function NumberIsNaN2(value) {
      return value !== value;
    };
    function EventEmitter() {
      EventEmitter.init.call(this);
    }
    module.exports = EventEmitter;
    module.exports.once = once;
    EventEmitter.EventEmitter = EventEmitter;
    EventEmitter.prototype._events = void 0;
    EventEmitter.prototype._eventsCount = 0;
    EventEmitter.prototype._maxListeners = void 0;
    var defaultMaxListeners = 10;
    function checkListener(listener) {
      if (typeof listener !== "function") {
        throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
      }
    }
    Object.defineProperty(EventEmitter, "defaultMaxListeners", {
      enumerable: true,
      get: function() {
        return defaultMaxListeners;
      },
      set: function(arg) {
        if (typeof arg !== "number" || arg < 0 || NumberIsNaN(arg)) {
          throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + ".");
        }
        defaultMaxListeners = arg;
      }
    });
    EventEmitter.init = function() {
      if (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) {
        this._events = /* @__PURE__ */ Object.create(null);
        this._eventsCount = 0;
      }
      this._maxListeners = this._maxListeners || void 0;
    };
    EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
      if (typeof n !== "number" || n < 0 || NumberIsNaN(n)) {
        throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + ".");
      }
      this._maxListeners = n;
      return this;
    };
    function _getMaxListeners(that) {
      if (that._maxListeners === void 0)
        return EventEmitter.defaultMaxListeners;
      return that._maxListeners;
    }
    EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
      return _getMaxListeners(this);
    };
    EventEmitter.prototype.emit = function emit(type) {
      var args = [];
      for (var i = 1; i < arguments.length; i++)
        args.push(arguments[i]);
      var doError = type === "error";
      var events = this._events;
      if (events !== void 0)
        doError = doError && events.error === void 0;
      else if (!doError)
        return false;
      if (doError) {
        var er;
        if (args.length > 0)
          er = args[0];
        if (er instanceof Error) {
          throw er;
        }
        var err = new Error("Unhandled error." + (er ? " (" + er.message + ")" : ""));
        err.context = er;
        throw err;
      }
      var handler = events[type];
      if (handler === void 0)
        return false;
      if (typeof handler === "function") {
        ReflectApply(handler, this, args);
      } else {
        var len = handler.length;
        var listeners = arrayClone(handler, len);
        for (var i = 0; i < len; ++i)
          ReflectApply(listeners[i], this, args);
      }
      return true;
    };
    function _addListener(target, type, listener, prepend) {
      var m;
      var events;
      var existing;
      checkListener(listener);
      events = target._events;
      if (events === void 0) {
        events = target._events = /* @__PURE__ */ Object.create(null);
        target._eventsCount = 0;
      } else {
        if (events.newListener !== void 0) {
          target.emit(
            "newListener",
            type,
            listener.listener ? listener.listener : listener
          );
          events = target._events;
        }
        existing = events[type];
      }
      if (existing === void 0) {
        existing = events[type] = listener;
        ++target._eventsCount;
      } else {
        if (typeof existing === "function") {
          existing = events[type] = prepend ? [listener, existing] : [existing, listener];
        } else if (prepend) {
          existing.unshift(listener);
        } else {
          existing.push(listener);
        }
        m = _getMaxListeners(target);
        if (m > 0 && existing.length > m && !existing.warned) {
          existing.warned = true;
          var w = new Error("Possible EventEmitter memory leak detected. " + existing.length + " " + String(type) + " listeners added. Use emitter.setMaxListeners() to increase limit");
          w.name = "MaxListenersExceededWarning";
          w.emitter = target;
          w.type = type;
          w.count = existing.length;
          ProcessEmitWarning(w);
        }
      }
      return target;
    }
    EventEmitter.prototype.addListener = function addListener(type, listener) {
      return _addListener(this, type, listener, false);
    };
    EventEmitter.prototype.on = EventEmitter.prototype.addListener;
    EventEmitter.prototype.prependListener = function prependListener(type, listener) {
      return _addListener(this, type, listener, true);
    };
    function onceWrapper() {
      if (!this.fired) {
        this.target.removeListener(this.type, this.wrapFn);
        this.fired = true;
        if (arguments.length === 0)
          return this.listener.call(this.target);
        return this.listener.apply(this.target, arguments);
      }
    }
    function _onceWrap(target, type, listener) {
      var state = { fired: false, wrapFn: void 0, target, type, listener };
      var wrapped = onceWrapper.bind(state);
      wrapped.listener = listener;
      state.wrapFn = wrapped;
      return wrapped;
    }
    EventEmitter.prototype.once = function once2(type, listener) {
      checkListener(listener);
      this.on(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
      checkListener(listener);
      this.prependListener(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.removeListener = function removeListener(type, listener) {
      var list, events, position, i, originalListener;
      checkListener(listener);
      events = this._events;
      if (events === void 0)
        return this;
      list = events[type];
      if (list === void 0)
        return this;
      if (list === listener || list.listener === listener) {
        if (--this._eventsCount === 0)
          this._events = /* @__PURE__ */ Object.create(null);
        else {
          delete events[type];
          if (events.removeListener)
            this.emit("removeListener", type, list.listener || listener);
        }
      } else if (typeof list !== "function") {
        position = -1;
        for (i = list.length - 1; i >= 0; i--) {
          if (list[i] === listener || list[i].listener === listener) {
            originalListener = list[i].listener;
            position = i;
            break;
          }
        }
        if (position < 0)
          return this;
        if (position === 0)
          list.shift();
        else {
          spliceOne(list, position);
        }
        if (list.length === 1)
          events[type] = list[0];
        if (events.removeListener !== void 0)
          this.emit("removeListener", type, originalListener || listener);
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
      var listeners, events, i;
      events = this._events;
      if (events === void 0)
        return this;
      if (events.removeListener === void 0) {
        if (arguments.length === 0) {
          this._events = /* @__PURE__ */ Object.create(null);
          this._eventsCount = 0;
        } else if (events[type] !== void 0) {
          if (--this._eventsCount === 0)
            this._events = /* @__PURE__ */ Object.create(null);
          else
            delete events[type];
        }
        return this;
      }
      if (arguments.length === 0) {
        var keys = Object.keys(events);
        var key;
        for (i = 0; i < keys.length; ++i) {
          key = keys[i];
          if (key === "removeListener")
            continue;
          this.removeAllListeners(key);
        }
        this.removeAllListeners("removeListener");
        this._events = /* @__PURE__ */ Object.create(null);
        this._eventsCount = 0;
        return this;
      }
      listeners = events[type];
      if (typeof listeners === "function") {
        this.removeListener(type, listeners);
      } else if (listeners !== void 0) {
        for (i = listeners.length - 1; i >= 0; i--) {
          this.removeListener(type, listeners[i]);
        }
      }
      return this;
    };
    function _listeners(target, type, unwrap) {
      var events = target._events;
      if (events === void 0)
        return [];
      var evlistener = events[type];
      if (evlistener === void 0)
        return [];
      if (typeof evlistener === "function")
        return unwrap ? [evlistener.listener || evlistener] : [evlistener];
      return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
    }
    EventEmitter.prototype.listeners = function listeners(type) {
      return _listeners(this, type, true);
    };
    EventEmitter.prototype.rawListeners = function rawListeners(type) {
      return _listeners(this, type, false);
    };
    EventEmitter.listenerCount = function(emitter, type) {
      if (typeof emitter.listenerCount === "function") {
        return emitter.listenerCount(type);
      } else {
        return listenerCount.call(emitter, type);
      }
    };
    EventEmitter.prototype.listenerCount = listenerCount;
    function listenerCount(type) {
      var events = this._events;
      if (events !== void 0) {
        var evlistener = events[type];
        if (typeof evlistener === "function") {
          return 1;
        } else if (evlistener !== void 0) {
          return evlistener.length;
        }
      }
      return 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
    };
    function arrayClone(arr, n) {
      var copy = new Array(n);
      for (var i = 0; i < n; ++i)
        copy[i] = arr[i];
      return copy;
    }
    function spliceOne(list, index) {
      for (; index + 1 < list.length; index++)
        list[index] = list[index + 1];
      list.pop();
    }
    function unwrapListeners(arr) {
      var ret = new Array(arr.length);
      for (var i = 0; i < ret.length; ++i) {
        ret[i] = arr[i].listener || arr[i];
      }
      return ret;
    }
    function once(emitter, name) {
      return new Promise(function(resolve, reject) {
        function errorListener(err) {
          emitter.removeListener(name, resolver);
          reject(err);
        }
        function resolver() {
          if (typeof emitter.removeListener === "function") {
            emitter.removeListener("error", errorListener);
          }
          resolve([].slice.call(arguments));
        }
        ;
        eventTargetAgnosticAddListener(emitter, name, resolver, { once: true });
        if (name !== "error") {
          addErrorHandlerIfEventEmitter(emitter, errorListener, { once: true });
        }
      });
    }
    function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
      if (typeof emitter.on === "function") {
        eventTargetAgnosticAddListener(emitter, "error", handler, flags);
      }
    }
    function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
      if (typeof emitter.on === "function") {
        if (flags.once) {
          emitter.once(name, listener);
        } else {
          emitter.on(name, listener);
        }
      } else if (typeof emitter.addEventListener === "function") {
        emitter.addEventListener(name, function wrapListener(arg) {
          if (flags.once) {
            emitter.removeEventListener(name, wrapListener);
          }
          listener(arg);
        });
      } else {
        throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
      }
    }
  }
});

// ../dist/const.js
var require_const = __commonJS({
  "../dist/const.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.defaultSimulcastBitrates = exports.defaultBitrates = exports.simulcastTransceiverConfig = void 0;
    exports.simulcastTransceiverConfig = {
      direction: "sendonly",
      // keep this array from low resolution to high resolution
      // in other case lower resolution encoding can get
      // higher max_bitrate
      sendEncodings: [
        {
          rid: "l",
          active: false,
          // maxBitrate: 4_000_000,
          scaleResolutionDownBy: 4
          //   scalabilityMode: "L1T" + TEMPORAL_LAYERS_COUNT,
        },
        {
          rid: "m",
          active: false,
          scaleResolutionDownBy: 2
        },
        {
          rid: "h",
          active: false
          // maxBitrate: 4_000_000,
          // scalabilityMode: "L1T" + TEMPORAL_LAYERS_COUNT,
        }
      ]
    };
    exports.defaultBitrates = { audio: 5e4, video: 25e5 };
    exports.defaultSimulcastBitrates = {
      h: 25e5,
      m: 5e5,
      l: 15e4
    };
  }
});

// ../dist/webRTCEndpoint.js
var require_webRTCEndpoint = __commonJS({
  "../dist/webRTCEndpoint.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.WebRTCEndpoint = void 0;
    var mediaEvent_1 = require_mediaEvent();
    var uuid_1 = (init_esm_browser(), __toCommonJS(esm_browser_exports));
    var events_1 = require_events();
    var const_1 = require_const();
    var vadStatuses = ["speech", "silence"];
    var TrackContextImpl = class extends events_1.EventEmitter {
      constructor(endpoint, trackId, metadata, simulcastConfig) {
        super();
        this.track = null;
        this.stream = null;
        this.maxBandwidth = 0;
        this.vadStatus = "silence";
        this.negotiationStatus = "awaiting";
        this.pendingMetadataUpdate = false;
        this.endpoint = endpoint;
        this.trackId = trackId;
        this.metadata = metadata;
        this.simulcastConfig = simulcastConfig;
      }
    };
    var WebRTCEndpoint = class extends events_1.EventEmitter {
      constructor() {
        super();
        this.localTracksWithStreams = [];
        this.trackIdToTrack = /* @__PURE__ */ new Map();
        this.idToEndpoint = /* @__PURE__ */ new Map();
        this.localEndpoint = {
          id: "",
          type: "webrtc",
          metadata: {},
          tracks: /* @__PURE__ */ new Map()
        };
        this.localTrackIdToTrack = /* @__PURE__ */ new Map();
        this.midToTrackId = /* @__PURE__ */ new Map();
        this.disabledTrackEncodings = /* @__PURE__ */ new Map();
        this.rtcConfig = {
          bundlePolicy: "max-bundle",
          iceServers: [],
          iceTransportPolicy: "relay"
        };
        this.connect = (metadata) => {
          this.localEndpoint.metadata = metadata;
          const mediaEvent = (0, mediaEvent_1.generateMediaEvent)("connect", {
            metadata
          });
          this.sendMediaEvent(mediaEvent);
        };
        this.receiveMediaEvent = (mediaEvent) => {
          const deserializedMediaEvent = (0, mediaEvent_1.deserializeMediaEvent)(mediaEvent);
          switch (deserializedMediaEvent.type) {
            case "connected": {
              this.localEndpoint.id = deserializedMediaEvent.data.id;
              this.emit("connected", deserializedMediaEvent.data.id, deserializedMediaEvent.data.otherEndpoints);
              const endpoints = deserializedMediaEvent.data.otherEndpoints;
              const otherEndpoints = endpoints.map((endpoint) => {
                endpoint.tracks = this.mapMediaEventTracksToTrackContextImpl(Array.from(endpoint.tracks), endpoint);
                this.addEndpoint(endpoint);
                return endpoint;
              });
              otherEndpoints.forEach((endpoint) => {
                Array.from(endpoint.tracks.entries()).forEach(([trackId, ctx]) => {
                  this.trackIdToTrack.set(trackId, ctx);
                  this.emit("trackAdded", ctx);
                });
              });
              break;
            }
            default:
              if (this.localEndpoint.id != null)
                this.handleMediaEvent(deserializedMediaEvent);
          }
        };
        this.handleMediaEvent = (deserializedMediaEvent) => {
          let endpoint;
          let data;
          switch (deserializedMediaEvent.type) {
            case "offerData": {
              const turnServers = deserializedMediaEvent.data.integratedTurnServers;
              this.setTurns(turnServers);
              const offerData = new Map(Object.entries(deserializedMediaEvent.data.tracksTypes));
              this.onOfferData(offerData);
              break;
            }
            case "tracksAdded": {
              data = deserializedMediaEvent.data;
              if (this.getEndpointId() === data.endpointId)
                return;
              data.tracks = new Map(Object.entries(data.tracks));
              endpoint = this.idToEndpoint.get(data.endpointId);
              const oldTracks = endpoint.tracks;
              data.tracks = this.mapMediaEventTracksToTrackContextImpl(data.tracks, endpoint);
              endpoint.tracks = new Map([...endpoint.tracks, ...data.tracks]);
              this.idToEndpoint.set(endpoint.id, endpoint);
              Array.from(endpoint.tracks.entries()).forEach(([trackId, ctx]) => {
                if (!oldTracks.has(trackId)) {
                  this.trackIdToTrack.set(trackId, ctx);
                  this.emit("trackAdded", ctx);
                }
              });
              break;
            }
            case "tracksRemoved": {
              data = deserializedMediaEvent.data;
              const endpointId = data.endpointId;
              if (this.getEndpointId() === endpointId)
                return;
              const trackIds = data.trackIds;
              trackIds.forEach((trackId) => {
                const trackContext = this.trackIdToTrack.get(trackId);
                this.emit("trackRemoved", trackContext);
                this.eraseTrack(trackId, endpointId);
              });
              break;
            }
            case "sdpAnswer":
              this.midToTrackId = new Map(Object.entries(deserializedMediaEvent.data.midToTrackId));
              for (const trackId of Object.values(deserializedMediaEvent.data.midToTrackId)) {
                const track = this.localTrackIdToTrack.get(trackId);
                if (track) {
                  track.negotiationStatus = "done";
                  if (track.pendingMetadataUpdate) {
                    const mediaEvent = (0, mediaEvent_1.generateMediaEvent)("updateTrackMetadata", {
                      trackId,
                      trackMetadata: track.metadata
                    });
                    this.sendMediaEvent(mediaEvent);
                  }
                  track.pendingMetadataUpdate = false;
                }
              }
              this.onAnswer(deserializedMediaEvent.data);
              break;
            case "candidate":
              this.onRemoteCandidate(deserializedMediaEvent.data);
              break;
            case "endpointAdded":
              endpoint = deserializedMediaEvent.data;
              if (endpoint.id === this.getEndpointId())
                return;
              this.addEndpoint(endpoint);
              this.emit("endpointAdded", endpoint);
              break;
            case "endpointRemoved":
              if (deserializedMediaEvent.data.id === this.localEndpoint.id) {
                this.cleanUp();
                this.emit("disconnected");
                return;
              }
              endpoint = this.idToEndpoint.get(deserializedMediaEvent.data.id);
              if (endpoint === void 0)
                return;
              Array.from(endpoint.tracks.keys()).forEach((trackId) => {
                this.emit("trackRemoved", this.trackIdToTrack.get(trackId));
              });
              this.eraseEndpoint(endpoint);
              this.emit("endpointRemoved", endpoint);
              break;
            case "endpointUpdated":
              if (this.getEndpointId() === deserializedMediaEvent.data.id)
                return;
              endpoint = this.idToEndpoint.get(deserializedMediaEvent.data.id);
              endpoint.metadata = deserializedMediaEvent.data.metadata;
              this.addEndpoint(endpoint);
              this.emit("endpointUpdated", endpoint);
              break;
            case "trackUpdated": {
              if (this.getEndpointId() === deserializedMediaEvent.data.endpointId)
                return;
              endpoint = this.idToEndpoint.get(deserializedMediaEvent.data.endpointId);
              if (endpoint == null)
                throw `Endpoint with id: ${deserializedMediaEvent.data.endpointId} doesn't exist`;
              const trackId = deserializedMediaEvent.data.trackId;
              const trackMetadata = deserializedMediaEvent.data.metadata;
              const prevTrack = endpoint.tracks.get(trackId);
              endpoint.tracks.set(trackId, { ...prevTrack, metadata: trackMetadata });
              const trackContext = this.trackIdToTrack.get(trackId);
              trackContext.metadata = trackMetadata;
              this.emit("trackUpdated", trackContext);
              break;
            }
            case "tracksPriority": {
              const enabledTracks = deserializedMediaEvent.data.tracks.map((trackId) => this.trackIdToTrack.get(trackId));
              const disabledTracks = Array.from(this.trackIdToTrack.values()).filter((track) => !enabledTracks.includes(track));
              this.emit("tracksPriorityChanged", enabledTracks, disabledTracks);
              break;
            }
            case "encodingSwitched": {
              const trackId = deserializedMediaEvent.data.trackId;
              const trackContext = this.trackIdToTrack.get(trackId);
              trackContext.encoding = deserializedMediaEvent.data.encoding;
              trackContext.encodingReason = deserializedMediaEvent.data.reason;
              trackContext.emit("encodingChanged", trackContext);
              break;
            }
            case "custom":
              this.handleMediaEvent(deserializedMediaEvent.data);
              break;
            case "error":
              this.emit("connectionError", deserializedMediaEvent.data.message);
              this.disconnect();
              break;
            case "vadNotification": {
              const trackId = deserializedMediaEvent.data.trackId;
              const ctx = this.trackIdToTrack.get(trackId);
              const vadStatus = deserializedMediaEvent.data.status;
              if (vadStatuses.includes(vadStatus)) {
                ctx.vadStatus = vadStatus;
                ctx.emit("voiceActivityChanged", ctx);
              } else {
                console.warn("Received unknown vad status: ", vadStatus);
              }
              break;
            }
            case "bandwidthEstimation": {
              const estimation = deserializedMediaEvent.data.estimation;
              this.emit("bandwidthEstimationChanged", estimation);
              break;
            }
            default:
              console.warn("Received unknown media event: ", deserializedMediaEvent.type);
              break;
          }
        };
        this.addTrackToConnection = (trackContext) => {
          const transceiverConfig = this.createTransceiverConfig(trackContext);
          const track = trackContext.track;
          this.connection.addTransceiver(track, transceiverConfig);
        };
        this.updateEndpointMetadata = (metadata) => {
          const mediaEvent = (0, mediaEvent_1.generateMediaEvent)("updateEndpointMetadata", {
            metadata
          });
          this.sendMediaEvent(mediaEvent);
        };
        this.updateTrackMetadata = (trackId, trackMetadata) => {
          const trackContext = this.localTrackIdToTrack.get(trackId);
          trackContext.metadata = trackMetadata;
          this.localTrackIdToTrack.set(trackId, trackContext);
          const prevTrack = this.localEndpoint.tracks.get(trackId);
          this.localEndpoint.tracks.set(trackId, { ...prevTrack, metadata: trackMetadata });
          const mediaEvent = (0, mediaEvent_1.generateMediaEvent)("updateTrackMetadata", {
            trackId,
            trackMetadata
          });
          switch (trackContext.negotiationStatus) {
            case "done":
              this.sendMediaEvent(mediaEvent);
              break;
            case "offered":
              trackContext.pendingMetadataUpdate = true;
              break;
            case "awaiting":
              break;
          }
        };
        this.getMidToTrackId = () => {
          const localTrackMidToTrackId = {};
          if (!this.connection)
            return null;
          this.connection.getTransceivers().forEach((transceiver) => {
            var _a;
            const localTrackId = (_a = transceiver.sender.track) === null || _a === void 0 ? void 0 : _a.id;
            const mid = transceiver.mid;
            if (localTrackId && mid) {
              const trackContext = Array.from(this.localTrackIdToTrack.values()).find((trackContext2) => trackContext2.track.id === localTrackId);
              localTrackMidToTrackId[mid] = trackContext.trackId;
            }
          });
          return localTrackMidToTrackId;
        };
        this.disconnect = () => {
          const mediaEvent = (0, mediaEvent_1.generateMediaEvent)("disconnect");
          this.sendMediaEvent(mediaEvent);
          this.cleanUp();
        };
        this.cleanUp = () => {
          if (this.connection) {
            this.connection.onicecandidate = null;
            this.connection.ontrack = null;
            this.connection.onconnectionstatechange = null;
            this.connection.onicecandidateerror = null;
            this.connection.oniceconnectionstatechange = null;
          }
          this.localTracksWithStreams = [];
          this.connection = void 0;
        };
        this.sendMediaEvent = (mediaEvent) => {
          const serializedMediaEvent = (0, mediaEvent_1.serializeMediaEvent)(mediaEvent);
          this.emit("sendMediaEvent", serializedMediaEvent);
        };
        this.onAnswer = async (answer) => {
          this.connection.ontrack = this.onTrack();
          try {
            await this.connection.setRemoteDescription(answer);
            this.disabledTrackEncodings.forEach((encodings, trackId) => {
              encodings.forEach((encoding) => this.disableTrackEncoding(trackId, encoding));
            });
          } catch (err) {
            console.error(err);
          }
        };
        this.addTransceiversIfNeeded = (serverTracks) => {
          var _a;
          const recvTransceivers = this.connection.getTransceivers().filter((elem) => elem.direction === "recvonly");
          let toAdd = [];
          const getNeededTransceiversTypes = (type) => {
            let typeNumber = serverTracks.get(type);
            typeNumber = typeNumber !== void 0 ? typeNumber : 0;
            const typeTransceiversNumber = recvTransceivers.filter((elem) => elem.receiver.track.kind === type).length;
            return Array(typeNumber - typeTransceiversNumber).fill(type);
          };
          const audio = getNeededTransceiversTypes("audio");
          const video = getNeededTransceiversTypes("video");
          toAdd = toAdd.concat(audio);
          toAdd = toAdd.concat(video);
          for (const kind of toAdd)
            (_a = this.connection) === null || _a === void 0 ? void 0 : _a.addTransceiver(kind, { direction: "recvonly" });
        };
        this.getTrackIdToMetadata = () => {
          const trackIdToMetadata = {};
          Array.from(this.localEndpoint.tracks.entries()).forEach(([trackId, { metadata }]) => {
            trackIdToMetadata[trackId] = metadata;
          });
          return trackIdToMetadata;
        };
        this.getTrackBitrates = (trackId) => {
          const trackContext = this.localTrackIdToTrack.get(trackId);
          if (!trackContext)
            throw "Track with id ${trackId} not present in 'localTrackIdToTrack'";
          const kind = trackContext.track.kind;
          const sender = this.findSender(trackContext.track.id);
          const encodings = sender.getParameters().encodings;
          if (encodings.length == 1 && !encodings[0].rid)
            return encodings[0].maxBitrate || const_1.defaultBitrates[kind];
          else if (kind == "audio")
            throw "Audio track cannot have multiple encodings";
          const bitrates = {};
          encodings.filter((encoding) => encoding.rid).forEach((encoding) => {
            const rid = encoding.rid;
            bitrates[rid] = encoding.maxBitrate || const_1.defaultSimulcastBitrates[rid];
          });
          return bitrates;
        };
        this.getTrackIdToTrackBitrates = () => {
          const trackIdToTrackBitrates = {};
          Array.from(this.localEndpoint.tracks.entries()).forEach(([trackId, _trackEntry]) => {
            trackIdToTrackBitrates[trackId] = this.getTrackBitrates(trackId);
          });
          return trackIdToTrackBitrates;
        };
        this.checkIfTrackBelongToEndpoint = (trackId, endpoint) => Array.from(endpoint.tracks.keys()).some((track) => trackId.startsWith(track));
        this.onOfferData = async (offerData) => {
          if (!this.connection) {
            this.connection = new RTCPeerConnection(this.rtcConfig);
            this.connection.onicecandidate = this.onLocalCandidate();
            this.connection.onicecandidateerror = this.onIceCandidateError;
            this.connection.onconnectionstatechange = this.onConnectionStateChange;
            this.connection.oniceconnectionstatechange = this.onIceConnectionStateChange;
            Array.from(this.localTrackIdToTrack.values()).forEach((trackContext) => this.addTrackToConnection(trackContext));
            this.connection.getTransceivers().forEach((transceiver) => transceiver.direction = "sendonly");
          } else {
            await this.connection.restartIce();
          }
          this.addTransceiversIfNeeded(offerData);
          await this.createAndSendOffer();
        };
        this.onRemoteCandidate = (candidate) => {
          try {
            const iceCandidate = new RTCIceCandidate(candidate);
            if (!this.connection) {
              throw new Error("Received new remote candidate but RTCConnection is undefined");
            }
            this.connection.addIceCandidate(iceCandidate);
          } catch (error) {
            console.error(error);
          }
        };
        this.onLocalCandidate = () => {
          return (event) => {
            if (event.candidate) {
              const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({
                type: "candidate",
                data: {
                  candidate: event.candidate.candidate,
                  sdpMLineIndex: event.candidate.sdpMLineIndex
                }
              });
              this.sendMediaEvent(mediaEvent);
            }
          };
        };
        this.onIceCandidateError = (event) => {
          console.warn(event);
        };
        this.onConnectionStateChange = (_event) => {
          var _a;
          if (((_a = this.connection) === null || _a === void 0 ? void 0 : _a.connectionState) === "failed") {
            const message = "Connection failed";
            this.emit("connectionError", message);
          }
        };
        this.onIceConnectionStateChange = (_event) => {
          var _a;
          const errorMessages = "Ice connection failed";
          switch ((_a = this.connection) === null || _a === void 0 ? void 0 : _a.iceConnectionState) {
            case "disconnected":
              console.warn("ICE connection: disconnected");
              break;
            case "failed":
              this.emit("connectionError", errorMessages);
              break;
          }
        };
        this.onTrack = () => {
          return (event) => {
            const [stream] = event.streams;
            const mid = event.transceiver.mid;
            const trackId = this.midToTrackId.get(mid);
            if (this.checkIfTrackBelongToEndpoint(trackId, this.localEndpoint))
              return;
            const trackContext = this.trackIdToTrack.get(trackId);
            trackContext.stream = stream;
            trackContext.track = event.track;
            this.emit("trackReady", trackContext);
          };
        };
        this.setTurns = (turnServers) => {
          turnServers.forEach((turnServer) => {
            let transport, uri;
            if (turnServer.transport == "tls") {
              transport = "tcp";
              uri = "turns";
            } else {
              transport = turnServer.transport;
              uri = "turn";
            }
            const rtcIceServer = {
              credential: turnServer.password,
              urls: uri.concat(":", turnServer.serverAddr, ":", turnServer.serverPort, "?transport=", transport),
              username: turnServer.username
            };
            this.rtcConfig.iceServers.push(rtcIceServer);
          });
        };
        this.addEndpoint = (endpoint) => {
          if (Object.prototype.hasOwnProperty.call(endpoint, "trackIdToMetadata"))
            endpoint.tracks = new Map(Object.entries(endpoint.tracks));
          else
            endpoint.tracks = /* @__PURE__ */ new Map();
          this.idToEndpoint.set(endpoint.id, endpoint);
        };
        this.eraseEndpoint = (endpoint) => {
          const tracksId = Array.from(endpoint.tracks.keys());
          tracksId.forEach((trackId) => this.trackIdToTrack.delete(trackId));
          Array.from(this.midToTrackId.entries()).forEach(([mid, trackId]) => {
            if (tracksId.includes(trackId))
              this.midToTrackId.delete(mid);
          });
          this.idToEndpoint.delete(endpoint.id);
        };
        this.eraseTrack = (trackId, endpointId) => {
          this.trackIdToTrack.delete(trackId);
          const midToTrackId = Array.from(this.midToTrackId.entries());
          const [mid, _trackId] = midToTrackId.find(([_mid, mapTrackId]) => mapTrackId === trackId);
          this.midToTrackId.delete(mid);
          this.idToEndpoint.get(endpointId).tracks.delete(trackId);
          this.disabledTrackEncodings.delete(trackId);
        };
        this.getEndpointId = () => this.localEndpoint.id;
        this.mapMediaEventTracksToTrackContextImpl = (tracks, endpoint) => {
          const mappedTracks = Array.from(tracks).map(([trackId, track]) => [
            trackId,
            new TrackContextImpl(endpoint, trackId, track.metadata, track.simulcastConfig)
          ]);
          return new Map(mappedTracks);
        };
      }
      /**
       * Returns a snapshot of currently received remote tracks.
       *
       * @example
       * if (webRTCEndpoint.getRemoteTracks()[trackId]?.simulcastConfig?.enabled) {
       *   webRTCEndpoint.setTargetTrackEncoding(trackId, encoding);
       * }
       */
      getRemoteTracks() {
        return Object.fromEntries(this.trackIdToTrack.entries());
      }
      /**
       * Adds track that will be sent to the RTC Engine.
       * @param track - Audio or video track e.g. from your microphone or camera.
       * @param stream  - Stream that this track belongs to.
       * @param trackMetadata - Any information about this track that other endpoints will
       * receive in {@link WebRTCEndpointEvents.endpointAdded}. E.g. this can source of the track - whether it's
       * screensharing, webcam or some other media device.
       * @param simulcastConfig - Simulcast configuration. By default simulcast is disabled.
       * For more information refer to {@link SimulcastConfig}.
       * @param maxBandwidth - maximal bandwidth this track can use.
       * Defaults to 0 which is unlimited.
       * This option has no effect for simulcast and audio tracks.
       * For simulcast tracks use `{@link WebRTCEndpoint.setTrackBandwidth}.
       * @returns {string} Returns id of added track
       * @example
       * ```ts
       * let localStream: MediaStream = new MediaStream();
       * try {
       *   localAudioStream = await navigator.mediaDevices.getUserMedia(
       *     AUDIO_CONSTRAINTS
       *   );
       *   localAudioStream
       *     .getTracks()
       *     .forEach((track) => localStream.addTrack(track));
       * } catch (error) {
       *   console.error("Couldn't get microphone permission:", error);
       * }
       *
       * try {
       *   localVideoStream = await navigator.mediaDevices.getUserMedia(
       *     VIDEO_CONSTRAINTS
       *   );
       *   localVideoStream
       *     .getTracks()
       *     .forEach((track) => localStream.addTrack(track));
       * } catch (error) {
       *  console.error("Couldn't get camera permission:", error);
       * }
       *
       * localStream
       *  .getTracks()
       *  .forEach((track) => webrtc.addTrack(track, localStream));
       * ```
       */
      addTrack(track, stream, trackMetadata = /* @__PURE__ */ new Map(), simulcastConfig = { enabled: false, activeEncodings: [] }, maxBandwidth = 0) {
        var _a;
        const isUsedTrack = (_a = this.connection) === null || _a === void 0 ? void 0 : _a.getSenders().some((val) => val.track === track);
        if (isUsedTrack) {
          throw "This track was already added to peerConnection, it can't be added again!";
        }
        if (!simulcastConfig.enabled && !(typeof maxBandwidth === "number"))
          throw "Invalid type of `maxBandwidth` argument for a non-simulcast track, expected: number";
        if (this.getEndpointId() === "")
          throw "Cannot add tracks before being accepted by the server";
        const trackId = this.getTrackId((0, uuid_1.v4)());
        this.localTracksWithStreams.push({ track, stream });
        const trackContext = new TrackContextImpl(this.localEndpoint, trackId, trackMetadata, simulcastConfig);
        this.localEndpoint.tracks.set(trackId, trackContext);
        trackContext.track = track;
        trackContext.stream = stream;
        trackContext.maxBandwidth = maxBandwidth;
        this.localTrackIdToTrack.set(trackId, trackContext);
        if (this.connection) {
          this.addTrackToConnection(trackContext);
          this.connection.getTransceivers().forEach((transceiver) => transceiver.direction = transceiver.direction === "sendrecv" ? "sendonly" : transceiver.direction);
        }
        const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({ type: "renegotiateTracks" });
        this.sendMediaEvent(mediaEvent);
        return trackId;
      }
      createTransceiverConfig(trackContext) {
        let transceiverConfig;
        if (trackContext.track.kind === "audio") {
          transceiverConfig = this.createAudioTransceiverConfig(trackContext);
        } else {
          transceiverConfig = this.createVideoTransceiverConfig(trackContext);
        }
        return transceiverConfig;
      }
      createAudioTransceiverConfig(_trackContext) {
        return { direction: "sendonly" };
      }
      createVideoTransceiverConfig(trackContext) {
        var _a;
        let transceiverConfig;
        if (trackContext.simulcastConfig.enabled) {
          transceiverConfig = const_1.simulcastTransceiverConfig;
          const trackActiveEncodings = trackContext.simulcastConfig.activeEncodings;
          const disabledTrackEncodings = [];
          (_a = transceiverConfig.sendEncodings) === null || _a === void 0 ? void 0 : _a.forEach((encoding) => {
            if (trackActiveEncodings.includes(encoding.rid)) {
              encoding.active = true;
            } else {
              disabledTrackEncodings.push(encoding.rid);
            }
          });
          this.disabledTrackEncodings.set(trackContext.trackId, disabledTrackEncodings);
        } else {
          transceiverConfig = {
            direction: "sendonly",
            sendEncodings: [
              {
                active: true
              }
            ]
          };
        }
        if (trackContext.maxBandwidth && transceiverConfig.sendEncodings)
          this.applyBandwidthLimitation(transceiverConfig.sendEncodings, trackContext.maxBandwidth);
        return transceiverConfig;
      }
      applyBandwidthLimitation(encodings, max_bandwidth) {
        if (typeof max_bandwidth === "number") {
          this.splitBandwidth(encodings, max_bandwidth * 1024);
        } else {
          encodings.filter((encoding) => encoding.rid).forEach((encoding) => {
            const limit = max_bandwidth.get(encoding.rid) || 0;
            if (limit > 0) {
              encoding.maxBitrate = limit * 1024;
            } else
              delete encoding.maxBitrate;
          });
        }
      }
      splitBandwidth(encodings, bandwidth) {
        if (bandwidth === 0) {
          encodings.forEach((encoding) => delete encoding.maxBitrate);
          return;
        }
        if (encodings.length == 0) {
          console.error("Attempted to limit bandwidth of the track that doesn't have any encodings");
          return;
        }
        const firstScaleDownBy = encodings[0].scaleResolutionDownBy || 1;
        const bitrate_parts = encodings.reduce((acc, value) => acc + (firstScaleDownBy / (value.scaleResolutionDownBy || 1)) ** 2, 0);
        const x = bandwidth / bitrate_parts;
        encodings.forEach((value) => {
          value.maxBitrate = x * (firstScaleDownBy / (value.scaleResolutionDownBy || 1)) ** 2;
        });
      }
      /**
       * Replaces a track that is being sent to the RTC Engine.
       * @param track - Audio or video track.
       * @param {string} trackId - Id of audio or video track to replace.
       * @param {MediaStreamTrack} newTrack
       * @param {any} [newMetadata] - Optional track metadata to apply to the new track. If no
       *                              track metadata is passed, the old track metadata is retained.
       * @returns {Promise<boolean>} success
       * @example
       * ```ts
       * // setup camera
       * let localStream: MediaStream = new MediaStream();
       * try {
       *   localVideoStream = await navigator.mediaDevices.getUserMedia(
       *     VIDEO_CONSTRAINTS
       *   );
       *   localVideoStream
       *     .getTracks()
       *     .forEach((track) => localStream.addTrack(track));
       * } catch (error) {
       *   console.error("Couldn't get camera permission:", error);
       * }
       * let oldTrackId;
       * localStream
       *  .getTracks()
       *  .forEach((track) => trackId = webrtc.addTrack(track, localStream));
       *
       * // change camera
       * const oldTrack = localStream.getVideoTracks()[0];
       * let videoDeviceId = "abcd-1234";
       * navigator.mediaDevices.getUserMedia({
       *      video: {
       *        ...(VIDEO_CONSTRAINTS as {}),
       *        deviceId: {
       *          exact: videoDeviceId,
       *        },
       *      }
       *   })
       *   .then((stream) => {
       *     let videoTrack = stream.getVideoTracks()[0];
       *     webrtc.replaceTrack(oldTrackId, videoTrack);
       *   })
       *   .catch((error) => {
       *     console.error('Error switching camera', error);
       *   })
       * ```
       */
      async replaceTrack(trackId, newTrack, newTrackMetadata) {
        const trackContext = this.localTrackIdToTrack.get(trackId);
        const sender = this.findSender(trackContext.track.id);
        if (sender) {
          return sender.replaceTrack(newTrack).then(() => {
            const trackMetadata = newTrackMetadata || this.localTrackIdToTrack.get(trackId).metadata;
            trackContext.track = newTrack;
            this.updateTrackMetadata(trackId, trackMetadata);
            return true;
          }).catch(() => false);
        }
        return false;
      }
      /**
       * Updates maximum bandwidth for the track identified by trackId.
       * This value directly translates to quality of the stream and, in case of video, to the amount of RTP packets being sent.
       * In case trackId points at the simulcast track bandwidth is split between all of the variant streams proportionally to their resolution.
       *
       * @param {string} trackId
       * @param {BandwidthLimit} bandwidth in kbps
       * @returns {Promise<boolean>} success
       */
      setTrackBandwidth(trackId, bandwidth) {
        const trackContext = this.localTrackIdToTrack.get(trackId);
        if (!trackContext) {
          return Promise.reject(`Track '${trackId}' doesn't exist`);
        }
        const sender = this.findSender(trackContext.track.id);
        const parameters = sender.getParameters();
        if (parameters.encodings.length === 0) {
          parameters.encodings = [{}];
        } else {
          this.applyBandwidthLimitation(parameters.encodings, bandwidth);
        }
        return sender.setParameters(parameters).then(() => {
          const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({
            type: "trackVariantBitrates",
            data: {
              trackId,
              variantBitrates: this.getTrackBitrates(trackId)
            }
          });
          this.sendMediaEvent(mediaEvent);
          return true;
        }).catch((_error) => false);
      }
      /**
       * Updates maximum bandwidth for the given simulcast encoding of the given track.
       *
       * @param {string} trackId - id of the track
       * @param {string} rid - rid of the encoding
       * @param {BandwidthLimit} bandwidth - desired max bandwidth used by the encoding (in kbps)
       * @returns
       */
      setEncodingBandwidth(trackId, rid, bandwidth) {
        const trackContext = this.localTrackIdToTrack.get(trackId);
        if (!trackContext) {
          return Promise.reject(`Track '${trackId}' doesn't exist`);
        }
        const sender = this.findSender(trackContext.track.id);
        const parameters = sender.getParameters();
        const encoding = parameters.encodings.find((encoding2) => encoding2.rid === rid);
        if (!encoding) {
          return Promise.reject(`Encoding with rid '${rid}' doesn't exist`);
        } else if (bandwidth === 0) {
          delete encoding.maxBitrate;
        } else {
          encoding.maxBitrate = bandwidth * 1024;
        }
        return sender.setParameters(parameters).then(() => {
          const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({
            type: "trackVariantBitrates",
            data: {
              trackId,
              variantBitrates: this.getTrackBitrates(trackId)
            }
          });
          this.sendMediaEvent(mediaEvent);
          return true;
        }).catch((_error) => false);
      }
      /**
       * Removes a track from connection that was sent to the RTC Engine.
       * @param {string} trackId - Id of audio or video track to remove.
       * @example
       * ```ts
       * // setup camera
       * let localStream: MediaStream = new MediaStream();
       * try {
       *   localVideoStream = await navigator.mediaDevices.getUserMedia(
       *     VIDEO_CONSTRAINTS
       *   );
       *   localVideoStream
       *     .getTracks()
       *     .forEach((track) => localStream.addTrack(track));
       * } catch (error) {
       *   console.error("Couldn't get camera permission:", error);
       * }
       *
       * let trackId
       * localStream
       *  .getTracks()
       *  .forEach((track) => trackId = webrtc.addTrack(track, localStream));
       *
       * // remove track
       * webrtc.removeTrack(trackId)
       * ```
       */
      removeTrack(trackId) {
        const trackContext = this.localTrackIdToTrack.get(trackId);
        const sender = this.findSender(trackContext.track.id);
        this.connection.removeTrack(sender);
        const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({ type: "renegotiateTracks" });
        this.sendMediaEvent(mediaEvent);
        this.localTrackIdToTrack.delete(trackId);
        this.localEndpoint.tracks.delete(trackId);
      }
      /**
       * Currently, this function only works when DisplayManager in RTC Engine is
       * enabled and simulcast is disabled.
       *
       * Prioritizes a track in connection to be always sent to browser.
       *
       * @param {string} trackId - Id of video track to prioritize.
       */
      prioritizeTrack(trackId) {
        const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({
          type: "prioritizeTrack",
          data: { trackId }
        });
        this.sendMediaEvent(mediaEvent);
      }
      /**
       * Currently, this function only works when DisplayManager in RTC Engine is
       * enabled and simulcast is disabled.
       *
       * Unprioritizes a track.
       *
       * @param {string} trackId - Id of video track to unprioritize.
       */
      unprioritizeTrack(trackId) {
        const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({
          type: "unprioritizeTrack",
          data: { trackId }
        });
        this.sendMediaEvent(mediaEvent);
      }
      /**
       * Currently this function has no effect.
       *
       * This function allows to adjust resolution and number of video tracks sent by an SFU to a client.
       *
       * @param {number} bigScreens - number of screens with big size
       * (if simulcast is used this will limit number of tracks sent with highest quality).
       * @param {number} smallScreens - number of screens with small size
       * (if simulcast is used this will limit number of tracks sent with lowest quality).
       * @param {number} mediumScreens - number of screens with medium size
       * (if simulcast is used this will limit number of tracks sent with medium quality).
       * @param {boolean} allSameSize - flag that indicates whether all screens should use the same quality
       */
      setPreferedVideoSizes(bigScreens, smallScreens, mediumScreens = 0, allSameSize = false) {
        const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({
          type: "preferedVideoSizes",
          data: { bigScreens, mediumScreens, smallScreens, allSameSize }
        });
        this.sendMediaEvent(mediaEvent);
      }
      /**
       * Sets track encoding that server should send to the client library.
       *
       * The encoding will be sent whenever it is available.
       * If chosen encoding is temporarily unavailable, some other encoding
       * will be sent until the chosen encoding becomes active again.
       *
       * @param {string} trackId - id of track
       * @param {TrackEncoding} encoding - encoding to receive
       * @example
       * ```ts
       * webrtc.setTargetTrackEncoding(incomingTrackCtx.trackId, "l")
       * ```
       */
      setTargetTrackEncoding(trackId, encoding) {
        const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({
          type: "setTargetTrackVariant",
          data: {
            trackId,
            variant: encoding
          }
        });
        this.sendMediaEvent(mediaEvent);
      }
      /**
       * Enables track encoding so that it will be sent to the server.
       * @param {string} trackId - id of track
       * @param {TrackEncoding} encoding - encoding that will be enabled
       * @example
       * ```ts
       * const trackId = webrtc.addTrack(track, stream, {}, {enabled: true, activeEncodings: ["l", "m", "h"]});
       * webrtc.disableTrackEncoding(trackId, "l");
       * // wait some time
       * webrtc.enableTrackEncoding(trackId, "l");
       * ```
       */
      enableTrackEncoding(trackId, encoding) {
        var _a, _b, _c;
        const track = (_a = this.localTrackIdToTrack.get(trackId)) === null || _a === void 0 ? void 0 : _a.track;
        const newDisabledTrackEncodings = (_b = this.disabledTrackEncodings.get(trackId)) === null || _b === void 0 ? void 0 : _b.filter((en) => en !== encoding);
        this.disabledTrackEncodings.set(trackId, newDisabledTrackEncodings);
        const sender = (_c = this.connection) === null || _c === void 0 ? void 0 : _c.getSenders().filter((sender2) => sender2.track === track)[0];
        const params = sender === null || sender === void 0 ? void 0 : sender.getParameters();
        params.encodings.filter((en) => en.rid == encoding)[0].active = true;
        sender === null || sender === void 0 ? void 0 : sender.setParameters(params);
      }
      /**
       * Disables track encoding so that it will be no longer sent to the server.
       * @param {string} trackId - id of track
       * @param {rackEncoding} encoding - encoding that will be disabled
       * @example
       * ```ts
       * const trackId = webrtc.addTrack(track, stream, {}, {enabled: true, activeEncodings: ["l", "m", "h"]});
       * webrtc.disableTrackEncoding(trackId, "l");
       * ```
       */
      disableTrackEncoding(trackId, encoding) {
        var _a, _b;
        const track = (_a = this.localTrackIdToTrack.get(trackId)) === null || _a === void 0 ? void 0 : _a.track;
        this.disabledTrackEncodings.get(trackId).push(encoding);
        const sender = (_b = this.connection) === null || _b === void 0 ? void 0 : _b.getSenders().filter((sender2) => sender2.track === track)[0];
        const params = sender === null || sender === void 0 ? void 0 : sender.getParameters();
        params.encodings.filter((en) => en.rid == encoding)[0].active = false;
        sender === null || sender === void 0 ? void 0 : sender.setParameters(params);
      }
      findSender(trackId) {
        return this.connection.getSenders().find((sender) => sender.track && sender.track.id === trackId);
      }
      getTrackId(uuid) {
        return `${this.getEndpointId()}:${uuid}`;
      }
      async createAndSendOffer() {
        if (!this.connection)
          return;
        try {
          const offer = await this.connection.createOffer();
          await this.connection.setLocalDescription(offer);
          const mediaEvent = (0, mediaEvent_1.generateCustomEvent)({
            type: "sdpOffer",
            data: {
              sdpOffer: offer,
              trackIdToTrackMetadata: this.getTrackIdToMetadata(),
              trackIdToTrackBitrates: this.getTrackIdToTrackBitrates(),
              midToTrackId: this.getMidToTrackId()
            }
          });
          this.sendMediaEvent(mediaEvent);
          for (const track of this.localTrackIdToTrack.values()) {
            track.negotiationStatus = "offered";
          }
        } catch (error) {
          console.error(error);
        }
      }
    };
    exports.WebRTCEndpoint = WebRTCEndpoint;
  }
});

// ../dist/index.js
var require_dist = __commonJS({
  "../dist/index.js"(exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.WebRTCEndpoint = void 0;
    var webRTCEndpoint_1 = require_webRTCEndpoint();
    Object.defineProperty(exports, "WebRTCEndpoint", { enumerable: true, get: function() {
      return webRTCEndpoint_1.WebRTCEndpoint;
    } });
  }
});
export default require_dist();
//# sourceMappingURL=@jellyfish-dev_membrane-webrtc-js.js.map
